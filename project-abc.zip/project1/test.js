


for(var i=0; i<41;i++){
document.querySelectorAll(".myButton")[i].addEventListener("click",function () {

var text = this.innerHTML;
console.log(text);
audioPlay(text);
PlayAnimation(text);


})
}

document.addEventListener("keypress",function(event){

	var text = event.key;
	audioPlay(text);
	PlayAnimation(text);

	
})
	
	






function audioPlay(text) {

switch (text){
			case"1":
			var audio = new Audio("sound/1.mp3");
			audio.play();
			break;case"2":
			var audio = new Audio("sound/2.mp3");
			audio.play();
			break;case"3":
			var audio = new Audio("sound/3.mp3");

			audio.play();
			break;case"4":
			var audio = new Audio("sound/4.mp3");
			audio.play();
			break;case"5":
			var audio = new Audio("sound/5.mp3");
			audio.play();
			break;case"6":
			var audio = new Audio("sound/6.mp3");
			audio.play();
			break;case"7":
			var audio = new Audio("sound/7.mp3");
			audio.play();
			break;case"8":
			var audio = new Audio("sound/8.mp3");
			audio.play();
			break;case"9":
			var audio = new Audio("sound/9.mp3");
			audio.play();
			break;case"10":
			var audio = new Audio("sound/10.mp3");
			audio.play();
			break;
			case"0":
			var audio = new Audio("sound/0.mp3");
			audio.play();
			break;
			case"A":
			var audio = new Audio("sound/a.mp3");
			audio.play();
			break;
			case"B":
			var audio = new Audio("sound/b.mp3");
			audio.play();
			break;
			case"C":
			var audio = new Audio("sound/c.mp3");
			audio.play();
			break;
			case"D":
			var audio = new Audio("sound/d.mp3");
			audio.play();
			break;

			case"E":
			var audio = new Audio("sound/e.mp3");
			audio.play();
			break;
			case"F":
			var audio = new Audio("sound/f.mp3");
			audio.play();
			break;
			case"G":
			var audio = new Audio("sound/g.mp3");
			audio.play();
			break;
			case"H":
			var audio = new Audio("sound/h.mp3");
			audio.play();
			break;

			case"I":
			var audio = new Audio("sound/i.mp3");
			audio.play();
			break;
			case"J":
			var audio = new Audio("sound/j.mp3");
			audio.play();
			break;
			case"K":
			var audio = new Audio("sound/k.mp3");1 
			audio.play();
			break;
			case"L":
			var audio = new Audio("sound/l.mp3");
			audio.play();
			break;

			case"M":
			var audio = new Audio("sound/m.mp3");
			audio.play();
			break;
			case"N":
			var audio = new Audio("sound/n.mp3");
			audio.play();
			break;
			case"O":
			var audio = new Audio("sound/o.mp3");
			audio.play();
			break;
			case"P":
			var audio = new Audio("sound/p.mp3");
			audio.play();
			break;

			case"Q":
			var audio = new Audio("sound/q.mp3");
			audio.play();
			break;
			case"R":
			var audio = new Audio("sound/r.mp3");
			audio.play();
			break;
			case"S":
			var audio = new Audio("sound/s.mp3");
			audio.play();
			break;
			case"T":
			var audio = new Audio("sound/t.mp3");
			audio.play();
			break;
			case"U":
			var audio = new Audio("sound/u.mp3");
			audio.play();
			break;

			case"V":
			var audio = new Audio("sound/v.mp3");
			audio.play();
			break;
			case"W":
			var audio = new Audio("sound/w.mp3");
			audio.play();
			break;
			case"X":
			var audio = new Audio("sound/x.mp3");
			audio.play();
			break;
			case"Y":
			var audio = new Audio("sound/y.mp3");
			audio.play();
			break;

			case"Z":
			var audio = new Audio("sound/z.mp3");
			audio.play();
			break;
}
}




function PlayAnimation(text){


var SelectedButton = document.querySelector("."+text);

SelectedButton.classList.add("anim");

setTimeout(function(){

	SelectedButton.classList.remove("anim");

},2000);


}



